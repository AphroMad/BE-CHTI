extern int index;

void CallbackSon(void);

void start_son();

int son();